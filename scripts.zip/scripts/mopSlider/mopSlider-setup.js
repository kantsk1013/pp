$(document).ready(function () {
    $("#catslider").mopSlider({
        'w': 960,
        'h': 130,
        'sldW': 800,
        'btnW': 170,
        'indi': "Slide For More",
        'type': 'ostemplates'
    });
});